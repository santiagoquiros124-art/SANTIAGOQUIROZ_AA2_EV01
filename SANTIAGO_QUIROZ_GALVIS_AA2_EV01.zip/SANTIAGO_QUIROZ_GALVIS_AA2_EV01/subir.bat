@echo off
chcp 65001 >nul
echo ============================================================
echo  GCM - Subir el proyecto a GitHub (Evidencia AA2-EV01)
echo ============================================================
echo.
echo ANTES de continuar: cree en github.com/new un repositorio VACIO
echo llamado gcm-modulo-citas (publico, sin README ni .gitignore).
echo.
where git >nul 2>&1
if errorlevel 1 (
  echo Git no esta instalado. Descarguelo de https://git-scm.com y vuelva a ejecutar.
  pause
  exit /b 1
)
cd /d "%~dp0gcm-modulo-citas"
set /p USUARIO=Escriba su usuario de GitHub [santiagoquiros124-art]: 
if "%USUARIO%"=="" set USUARIO=santiagoquiros124-art
git remote remove origin >nul 2>&1
git remote add origin https://github.com/%USUARIO%/gcm-modulo-citas.git
git branch -M main
echo.
echo Subiendo el proyecto con su historial de commits...
git push -u origin main
echo.
echo Si todo salio bien, su enlace es: https://github.com/%USUARIO%/gcm-modulo-citas
echo Si GitHub pide iniciar sesion, hagalo en la ventana del navegador que se abre.
pause
